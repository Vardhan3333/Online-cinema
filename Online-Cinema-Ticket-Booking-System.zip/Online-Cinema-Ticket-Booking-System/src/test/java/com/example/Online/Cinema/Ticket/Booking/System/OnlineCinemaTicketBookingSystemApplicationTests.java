package com.example.Online.Cinema.Ticket.Booking.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCinemaTicketBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.Online.Cinema.Ticket.Booking.System.Service;

import org.springframework.stereotype.Service;

@Service
public class TheatreDetailsService implements TheatreDetailsImpli{

}

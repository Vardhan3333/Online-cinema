package com.example.Online.Cinema.Ticket.Booking.System.Service;

public interface TheatreDetailsImpli {

}
